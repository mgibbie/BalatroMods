# Tag Team - Custom Joker for Balatro

![Metamorphosis Deck](./TagTeam/previews/preview.png)

This mod features one (1) custom Joker.

## How to install the mod

[Steamodded link to installing the mod](https://github.com/Steamopollys/Steamodded?tab=readme-ov-file#how-to-install-a-mod)
